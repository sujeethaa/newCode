package com.eCommerce.eCommerceDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
